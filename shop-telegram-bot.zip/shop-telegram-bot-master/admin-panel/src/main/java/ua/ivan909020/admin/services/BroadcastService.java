package ua.ivan909020.admin.services;

public interface BroadcastService {

    void send(String message);

}
