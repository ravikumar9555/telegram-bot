package ua.ivan909020.bot.repositories;

import ua.ivan909020.bot.models.entities.Order;

public interface OrderRepository {

    void save(Order order);

}
